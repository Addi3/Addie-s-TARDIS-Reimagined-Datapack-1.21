# STILL IN EARLY DEVELOPMENT!!
![logo](https://github.com/Addi3/Addie-s-TARDIS-Reimagined-Datapack-1.21/assets/122154427/b387c074-1f15-4dc8-ad20-4cdc64582132)



[DISCORD](https://discord.com/invite/cRPjGDy37p) | [DEV LOGS](https://youtube.com/playlist?list=PLnrSfYm4DiXkvuy0egSI8jkkjkd_lfECR&si=jPogT5T67gG-tEiM) | [WIKI](https://github.com/Addi3/Addie-s-TARDIS-Reimagined-Datapack-1.21/wiki)

------------------
# CREDITS
### Models / Textures / Main Coder : [Addi3](https://github.com/Addi3)
### Contributers : [MakeTendo](https://github.com/MaketendoDev)


